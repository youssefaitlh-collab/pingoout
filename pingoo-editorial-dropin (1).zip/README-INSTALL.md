# PINGOO editorial collections — drop-in files

This package adds a cautious editorial-candidate area to the existing Next.js App Router project.
It preserves all 56 titles from the supplied specification without claiming that the proposed
sales/trending labels are independently verified market rankings.

## Files to upload

Upload these paths into the repository root, preserving the folders:

- `lib/editorial-collections.ts`
- `app/editorial/page.tsx`
- `app/editorial/[slug]/page.tsx`

Do not replace any existing files. These are additive routes and a new data module.

## What it adds

- `/editorial` — lists the three proposed collections.
- `/editorial/[slug]` — an individual research-status page for each candidate.
- All candidate detail pages explicitly use `noindex` until there is researched, useful content.
- No invented release dates, platforms, system requirements, sources, rankings, prices or scores.
- Styling uses existing PINGOO class conventions and the existing site layout/header/footer.

## GitHub upload steps

1. Open the `youssefaitlh-collab/pingoout` repository.
2. Choose **Add file → Upload files**.
3. Extract this ZIP on your computer.
4. Upload the three files while preserving their relative folders. If the GitHub browser uploader does not preserve nested folders, create each folder/file through **Add file → Create new file** using the exact path shown above.
5. Commit to a new branch if possible, then let Vercel build the preview deployment.

## Important limits

This package is a safe first phase, not the full feature list from the specification. It does not implement authentication, a database, wishlists, realtime chat, or PayPal. Those features need real integrations, server-side authorization, secrets/environment variables, database policies and testing.

The existing site currently has a central catalog in `lib/games.ts` and source-checked entries in `lib/verified-games.js`. These editorial candidates are intentionally kept separate so unverified records cannot accidentally enter the public verified-game catalog.

## Validate after upload

Run:

```bash
npm run typecheck
npm run test
npm run build
```

If your repository's current baseline already has unrelated errors, distinguish them from errors introduced by these files. Review the Vercel build log before promoting the change to production.
