import Link from 'next/link'
import type { Metadata } from 'next'
import { notFound } from 'next/navigation'
import {
  editorialCandidates,
  editorialCollectionLabels,
  getEditorialCandidate,
} from '@/lib/editorial-collections'

type Props = { params: Promise<{ slug: string }> }

export function generateStaticParams() {
  return editorialCandidates.map(({ slug }) => ({ slug }))
}

export async function generateMetadata({ params }: Props): Promise<Metadata> {
  const { slug } = await params
  const candidate = getEditorialCandidate(slug)
  if (!candidate) return { title: 'Candidate not found', robots: { index: false, follow: true } }

  return {
    title: `${candidate.title} — editorial verification`,
    description: `PINGOO’s research status for ${candidate.title}. Facts and ranking claims are not published until reliable sources are checked.`,
    robots: { index: false, follow: true },
  }
}

export default async function EditorialCandidatePage({ params }: Props) {
  const { slug } = await params
  const candidate = getEditorialCandidate(slug)
  if (!candidate) notFound()

  return (
    <article className="container-page section max-w-4xl">
      <Link href="/editorial" className="text-sm text-cyan hover:underline">
        ← Back to editorial collections
      </Link>
      <p className="mt-6 text-sm font-semibold uppercase tracking-wider text-cyan">
        Editorial verification record
      </p>
      <h1 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
        {candidate.title}
      </h1>
      <p className="mt-4 text-muted">
        Proposed collection: {editorialCollectionLabels[candidate.category]}
      </p>

      <section className="mt-8 rounded-lg border border-line bg-surface p-5" aria-labelledby="status-title">
        <h2 id="status-title" className="text-lg font-semibold">Publication status</h2>
        <p className="mt-3 leading-relaxed">
          This title is retained as an editorial candidate, not a verified game profile.
          PINGOO has not confirmed the complete identity and current release status for this
          record in this implementation. No release date, developer, publisher, platform,
          price, PC requirement, popularity ranking, or review score is asserted here.
        </p>
        <p className="mt-3 text-sm text-muted">
          Status: Unconfirmed · Search indexing disabled until researched and reviewed.
        </p>
      </section>

      <section className="mt-8" aria-labelledby="next-steps-title">
        <h2 id="next-steps-title" className="text-lg font-semibold">Research checklist</h2>
        <ul className="mt-3 list-disc space-y-2 pl-5 text-muted">
          <li>Confirm the canonical title and whether the game or product is officially announced.</li>
          <li>Record official developer, publisher, release status and supported platforms.</li>
          <li>Use official PC requirements only when a publisher or authorized store publishes them.</li>
          <li>Verify any market-ranking claim against a dated source that identifies the region and metric.</li>
          <li>Add source URLs, the date checked, and field-level provenance before publication.</li>
        </ul>
      </section>
      <p className="mt-8">
        <Link href="/games" className="text-cyan hover:underline">
          Browse PINGOO’s existing game catalog →
        </Link>
      </p>
    </article>
  )
}
