import Link from 'next/link'
import type { Metadata } from 'next'
import {
  editorialCandidates,
  editorialCollectionLabels,
  type EditorialCollection,
} from '@/lib/editorial-collections'

export const metadata: Metadata = {
  title: 'Editorial game collections',
  description:
    'Explore PINGOO’s editorial game-candidate collections. Ranking labels are not presented as verified current market data.',
  robots: { index: false, follow: true },
}

const collections: EditorialCollection[] = [
  'best-selling-us',
  'trending-pc',
  'top-grossing-mobile-us',
]

export default function EditorialCollectionsPage() {
  return (
    <div className="container-page section">
      <header className="mb-8 max-w-3xl">
        <p className="text-sm font-semibold uppercase tracking-wider text-cyan">
          PINGOO editorial desk
        </p>
        <h1 className="mt-3 text-3xl font-bold tracking-tight md:text-4xl">
          Game collections under verification
        </h1>
        <p className="mt-4 leading-relaxed text-muted">
          These collections preserve the proposed editorial shortlist. Their category names
          are not claims that the titles currently lead sales, PC trends, or mobile revenue
          charts. Each candidate must be researched before a factual article is published.
        </p>
      </header>

      <div className="space-y-10">
        {collections.map((collection) => {
          const records = editorialCandidates.filter((item) => item.category === collection)
          return (
            <section key={collection} aria-labelledby={`${collection}-title`}>
              <div className="mb-4 flex flex-wrap items-end justify-between gap-3">
                <h2 id={`${collection}-title`} className="text-xl font-semibold">
                  {editorialCollectionLabels[collection]}
                </h2>
                <span className="text-sm text-muted">{records.length} candidates</span>
              </div>
              <ul className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
                {records.map((game) => (
                  <li key={game.id}>
                    <Link
                      href={`/editorial/${game.slug}`}
                      className="block h-full rounded-lg border border-line bg-surface p-4 transition-colors hover:border-cyan focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2"
                    >
                      <span className="font-medium">{game.title}</span>
                      <span className="mt-2 block text-xs text-muted">
                        Not yet verified · Not indexable
                      </span>
                    </Link>
                  </li>
                ))}
              </ul>
            </section>
          )
        })}
      </div>
    </div>
  )
}
