/**
 * PINGOO editorial collection candidates.
 *
 * These are owner-supplied candidate titles and collection labels, NOT verified rankings.
 * Keep records noindex/unconfirmed until an editor verifies the title identity, status,
 * platforms, release details and any ranking claim using authoritative sources.
 */
export type EditorialCollection =
  | 'best-selling-us'
  | 'trending-pc'
  | 'top-grossing-mobile-us'

export type EditorialVerificationStatus =
  | 'verified'
  | 'partially-verified'
  | 'upcoming'
  | 'unconfirmed'

export type EditorialCandidate = {
  id: string
  title: string
  slug: string
  category: EditorialCollection
  verificationStatus: EditorialVerificationStatus
  /** Candidate records are not indexable until substantive, sourced editorial content exists. */
  indexable: boolean
}

export const editorialCollectionLabels: Record<EditorialCollection, string> = {
  'best-selling-us': 'Best-selling in the US — candidate collection',
  'trending-pc': 'Trending on PC — candidate collection',
  'top-grossing-mobile-us': 'Top-grossing mobile games in the US — candidate collection',
}

export const editorialCandidates: EditorialCandidate[] = [
  {
    "id": "editorial-candidate-01",
    "title": "007 First Light",
    "slug": "007-first-light",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-02",
    "title": "MLB The Show 26",
    "slug": "mlb-the-show-26",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-03",
    "title": "Call of Duty: Black Ops II",
    "slug": "call-of-duty-black-ops-ii",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-04",
    "title": "Tomodachi Life: Living the Dream",
    "slug": "tomodachi-life-living-the-dream",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-05",
    "title": "LEGO Batman: Legacy of the Dark Knight",
    "slug": "lego-batman-legacy-of-the-dark-knight",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-06",
    "title": "Pokémon Pokopia",
    "slug": "pokemon-pokopia",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-07",
    "title": "EA Sports College Football 27",
    "slug": "ea-sports-college-football-27",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-08",
    "title": "WWE 2K26",
    "slug": "wwe-2k26",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-09",
    "title": "NBA 2K26",
    "slug": "nba-2k26",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-10",
    "title": "Pragmata",
    "slug": "pragmata",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-11",
    "title": "Assassin’s Creed: Black Flag Resynced",
    "slug": "assassins-creed-black-flag-resynced",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-12",
    "title": "Halo: Campaign Evolved",
    "slug": "halo-campaign-evolved",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-13",
    "title": "Splatoon Raiders",
    "slug": "splatoon-raiders",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-14",
    "title": "Echoes of Aincrad: Sword Art Online",
    "slug": "echoes-of-aincrad-sword-art-online",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-15",
    "title": "Call of Duty: Black Ops",
    "slug": "call-of-duty-black-ops",
    "category": "best-selling-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-16",
    "title": "Counter-Strike 2",
    "slug": "counter-strike-2",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-17",
    "title": "AION 2",
    "slug": "aion-2",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-18",
    "title": "Bongo Cat",
    "slug": "bongo-cat",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-19",
    "title": "Deadlock",
    "slug": "deadlock",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-20",
    "title": "WARDOGS",
    "slug": "wardogs",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-21",
    "title": "Valheim",
    "slug": "valheim",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-22",
    "title": "Rust",
    "slug": "rust",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-23",
    "title": "Team Fortress 2",
    "slug": "team-fortress-2",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-24",
    "title": "Overwatch",
    "slug": "overwatch",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-25",
    "title": "Tom Clancy’s Rainbow Six Siege",
    "slug": "tom-clancys-rainbow-six-siege",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-26",
    "title": "Marvel Rivals",
    "slug": "marvel-rivals",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-27",
    "title": "EA Sports FC 27",
    "slug": "ea-sports-fc-27",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-28",
    "title": "Aniimo",
    "slug": "aniimo",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-29",
    "title": "The Witcher 3: Wild Hunt (Remastered)",
    "slug": "the-witcher-3-wild-hunt-remastered",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-30",
    "title": "Apex Legends",
    "slug": "apex-legends",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-31",
    "title": "Project Zomboid",
    "slug": "project-zomboid",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-32",
    "title": "Slay the Spire 2",
    "slug": "slay-the-spire-2",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-33",
    "title": "Dead by Daylight",
    "slug": "dead-by-daylight",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-34",
    "title": "Baldur’s Gate 3",
    "slug": "baldurs-gate-3",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-35",
    "title": "Warframe",
    "slug": "warframe",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-36",
    "title": "Gears of War: E-Day",
    "slug": "gears-of-war-e-day",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-37",
    "title": "ACE COMBAT 8: Wings of Theve",
    "slug": "ace-combat-8-wings-of-theve",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-38",
    "title": "Risk of Rain 2",
    "slug": "risk-of-rain-2",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-39",
    "title": "Dragon’s Dogma 2",
    "slug": "dragons-dogma-2",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-40",
    "title": "Star Wars: Galactic Racer",
    "slug": "star-wars-galactic-racer",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-41",
    "title": "Call of Duty: Modern Warfare 4",
    "slug": "call-of-duty-modern-warfare-4",
    "category": "trending-pc",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-42",
    "title": "Monopoly GO!",
    "slug": "monopoly-go",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-43",
    "title": "Royal Match",
    "slug": "royal-match",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-44",
    "title": "Candy Crush Saga",
    "slug": "candy-crush-saga",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-45",
    "title": "Gossip Harbor",
    "slug": "gossip-harbor",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-46",
    "title": "Kingshot",
    "slug": "kingshot",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-47",
    "title": "Royal Kingdom",
    "slug": "royal-kingdom",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-48",
    "title": "Township",
    "slug": "township",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-49",
    "title": "Roblox",
    "slug": "roblox",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-50",
    "title": "Last War: Survival",
    "slug": "last-war-survival",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-51",
    "title": "Whiteout Survival",
    "slug": "whiteout-survival",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-52",
    "title": "Toon Blast",
    "slug": "toon-blast",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-53",
    "title": "NYT Games (Wordle & Crossword)",
    "slug": "nyt-games-wordle-and-crossword",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-54",
    "title": "Pokémon GO",
    "slug": "pokemon-go",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-55",
    "title": "Call of Duty: Mobile",
    "slug": "call-of-duty-mobile",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  },
  {
    "id": "editorial-candidate-56",
    "title": "Free Fire",
    "slug": "free-fire",
    "category": "top-grossing-mobile-us",
    "verificationStatus": "unconfirmed",
    "indexable": false
  }
] as EditorialCandidate[]

export function getEditorialCandidate(slug: string): EditorialCandidate | undefined {
  return editorialCandidates.find((candidate) => candidate.slug === slug)
}

export function getEditorialCandidatesByCollection(
  collection: EditorialCollection,
): EditorialCandidate[] {
  return editorialCandidates.filter((candidate) => candidate.category === collection)
}
